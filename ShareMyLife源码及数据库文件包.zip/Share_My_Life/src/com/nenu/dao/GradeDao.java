
package com.nenu.dao;

import com.nenu.bean.Grades;


public interface GradeDao {

	/**
	 * @param id
	 * @return
	 */
	public Grades find(int id);

}
