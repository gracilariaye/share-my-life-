
package com.nenu.service;

import com.nenu.bean.Comments;
import com.nenu.bean.Topics;
import com.nenu.bean.Users;


public interface CommentService {

	public boolean newComment(Comments comment, Users user, Topics topic);


	/**
	 * @param comment
	 * @param topic 
	 */
	public void deleteComment(Comments comment, Topics topic);
}
