/*
Navicat MySQL Data Transfer

Source Server         : 本地连接
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : db_sml_forum

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2021-06-20 13:47:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_announce`
-- ----------------------------
DROP TABLE IF EXISTS `t_announce`;
CREATE TABLE `t_announce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `announcement` longtext,
  `title` varchar(100) DEFAULT NULL,
  `newtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_announce
-- ----------------------------
INSERT INTO `t_announce` VALUES ('1', '请勿发表有关政治讨论', '注意', '2021-04-21 00:00:00');
INSERT INTO `t_announce` VALUES ('2', '请大家注意保护隐私安全，注意个人财产', '用户通知', '2021-03-25 00:00:00');
INSERT INTO `t_announce` VALUES ('3', '请大家谨慎发言，不要散布虚假信息，不要进行无意义的灌水', '发言请注意', '2021-03-30 00:00:00');
INSERT INTO `t_announce` VALUES ('4', '关于问题', '可联系管理员', '2021-05-03 00:00:00');
INSERT INTO `t_announce` VALUES ('5', '端午节祝大家安康', '端午节祝大家安康', '2021-06-14 00:00:00');
INSERT INTO `t_announce` VALUES ('6', '温馨提示', '请大家注意上网时间，合理利用', '2021-05-02 00:00:00');
INSERT INTO `t_announce` VALUES ('7', '欢迎新用户', '欢迎新用户', '2021-05-06 00:00:00');
INSERT INTO `t_announce` VALUES ('8', '请大家积极留言', '欢迎大家讨论问题', '2021-05-07 00:00:00');

-- ----------------------------
-- Table structure for `t_category`
-- ----------------------------
DROP TABLE IF EXISTS `t_category`;
CREATE TABLE `t_category` (
  `id` int(11) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `count_topics` int(11) DEFAULT '0',
  `count_comments` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_category
-- ----------------------------
INSERT INTO `t_category` VALUES ('1', '校园趣事', '3', '2');
INSERT INTO `t_category` VALUES ('2', '生活帮助', '3', '9');
INSERT INTO `t_category` VALUES ('3', '分享专区', '4', '14');
INSERT INTO `t_category` VALUES ('4', '学习交流', '1', '1');
INSERT INTO `t_category` VALUES ('5', '新生须知', '0', '0');
INSERT INTO `t_category` VALUES ('6', '社团活动', '1', '0');
INSERT INTO `t_category` VALUES ('7', '夜话围炉', '1', '5');
INSERT INTO `t_category` VALUES ('8', '交友', '6', '53');
INSERT INTO `t_category` VALUES ('9', '外校专区', '3', '11');
INSERT INTO `t_category` VALUES ('10', '东师老乡', '0', '0');

-- ----------------------------
-- Table structure for `t_comment`
-- ----------------------------
DROP TABLE IF EXISTS `t_comment`;
CREATE TABLE `t_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` longtext,
  `floor` int(11) DEFAULT NULL,
  `comment_time` datetime DEFAULT NULL,
  `comments_user_id` int(11) NOT NULL,
  `comments_topic_id` int(11) NOT NULL,
  `integral` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `comments_topic_id` (`comments_topic_id`) USING BTREE,
  KEY `comments_user_id` (`comments_user_id`),
  CONSTRAINT `comments_topic_id` FOREIGN KEY (`comments_topic_id`) REFERENCES `t_topic` (`id`),
  CONSTRAINT `comments_user_id` FOREIGN KEY (`comments_user_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_comment
-- ----------------------------
INSERT INTO `t_comment` VALUES ('1', '<p>大赞楼主<img src=\"http://img.baidu.com/hi/jx2/j_0057.gif\"/></p>', '1', '2021-03-22 18:06:01', '2', '2', '9', '0');
INSERT INTO `t_comment` VALUES ('2', '<p>去后街看看</p>', '1', '2021-05-07 18:06:46', '2', '1', '5', '0');
INSERT INTO `t_comment` VALUES ('3', '<p>可以找信息科学与技术学院的大佬帮忙看看呀</p>', '2', '2021-05-22 18:08:27', '2', '1', '5', '0');
INSERT INTO `t_comment` VALUES ('4', '<p>感谢各位捧场，哈哈哈<img src=\"http://img.baidu.com/hi/jx2/j_0028.gif\"/></p>', '2', '2021-04-21 10:26:29', '1', '2', '0', '0');
INSERT INTO `t_comment` VALUES ('5', '<p>不错不错，学习了</p>', '3', '2021-04-15 10:26:51', '1', '1', '0', '0');
INSERT INTO `t_comment` VALUES ('6', '<p>下午吗</p>', '1', '2021-05-12 10:34:23', '1', '5', '0', '1');
INSERT INTO `t_comment` VALUES ('7', '<p>貌似是艺术生吧</p>', '1', '2021-04-03 10:34:26', '1', '5', '0', '1');
INSERT INTO `t_comment` VALUES ('8', '<p>绿色我爱罗</p>', '1', '2021-05-01 10:34:28', '1', '5', '0', '1');
INSERT INTO `t_comment` VALUES ('9', '<p>见过好多次这个小姐姐</p>', '1', '2021-05-02 10:34:27', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('10', '<p>顶顶顶</p>', '1', '2021-05-03 09:00:00', '1', '5', '0', '1');
INSERT INTO `t_comment` VALUES ('11', '<p>想染</p>', '3', '2021-05-04 10:35:35', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('12', '<p>汉堡好吃吗<br/></p>', '4', '2021-05-05 10:39:00', '2', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('13', '<p>见过一只狸猫</p>', '1', '2021-05-06 10:42:12', '2', '6', '0', '0');
INSERT INTO `t_comment` VALUES ('14', 'dd', '1', '2021-05-07 10:44:15', '2', '7', '0', '0');
INSERT INTO `t_comment` VALUES ('15', '<p>顶顶顶<br/></p>', '5', '2021-05-08 10:46:13', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('16', '<p>好赞<br/></p>', '6', '2021-05-09 10:46:33', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('17', '<p>好赞<br/></p>', '7', '2021-05-11 10:47:12', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('18', '<p>好赞<br/></p>', '8', '2021-05-12 10:48:08', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('19', '<p>成为一名优秀的人民教师</p>', '1', '2021-05-22 10:48:51', '1', '8', '0', '0');
INSERT INTO `t_comment` VALUES ('20', 'dd', '1', '2021-05-11 10:58:38', '4', '9', '0', '0');
INSERT INTO `t_comment` VALUES ('21', '<fieldset style=\"font-size: 12px;border: 1px solid #CCC;word-break: break-word;word-wrap: break-word;overflow-x: hidden;margin: 0 0 5px 0;padding: 0 5px 5px;\"><legend style=\"font-weight:bold;font-size:14px;\">引自 1 楼 尘封记忆的十月 的回复</legend>\r\n										<p>链接进不去<img src=\"http://img.baidu.com/hi/jx2/j_0016.gif\"/></p>\r\n									</fieldset><p>这链接不管用，求楼主重发<br/></p>', '2', '2021-06-01 11:00:00', '4', '8', '0', '0');
INSERT INTO `t_comment` VALUES ('22', '<p>当然是开开心心的活着</p>', '3', '2021-06-12 11:01:35', '3', '8', '0', '0');
INSERT INTO `t_comment` VALUES ('23', '<p>学习了&nbsp;&nbsp; <img src=\"http://img.baidu.com/hi/jx2/j_0058.gif\"/></p>', '3', '2021-06-04 11:01:39', '4', '2', '1', '0');
INSERT INTO `t_comment` VALUES ('24', 'dd', '2', '2021-05-16 11:02:40', '4', '7', '0', '0');
INSERT INTO `t_comment` VALUES ('25', '<fieldset style=\"font-size: 12px;border: 1px solid #CCC;word-break: break-word;word-wrap: break-word;overflow-x: hidden;margin: 0 0 5px 0;padding: 0 5px 5px;\"><legend style=\"font-weight:bold;font-size:14px;\">引自 3 楼 我一直在这儿 的回复</legend>\r\n										<p><span style=\"line-height: 0px;\">﻿</span><a href=\"http://pan.baidu.com/s/1sjnsCBb\">http://pan.baidu.com/s/1sjnsCBb</a></p><p>&nbsp;</p><p>刚更正的公开链接&nbsp; 嘻嘻 前面的不好意思啊</p><p>&nbsp;</p>\r\n									</fieldset><p>不错，感谢楼主分享<img src=\"http://img.baidu.com/hi/jx2/j_0069.gif\"/></p>', '4', '2021-05-19 11:03:25', '4', '8', '0', '0');
INSERT INTO `t_comment` VALUES ('26', '<p>好多只啊</p>', '2', '2021-05-18 11:04:17', '4', '6', '0', '0');
INSERT INTO `t_comment` VALUES ('27', '<p>可以直接去超市或者水之源<img src=\"http://img.baidu.com/hi/jx2/j_0028.gif\"/></p>', '1', '2021-05-20 11:05:23', '4', '3', '10', '0');
INSERT INTO `t_comment` VALUES ('28', '<p>根本找不到<br/></p>', '1', '2021-06-03 11:07:32', '4', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('29', '<p>怎么没人来交朋友啊<br/></p>', '2', '2021-05-26 00:00:00', '4', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('30', '<p>小猫吃冰淇淋会窜稀吗</p>', '3', '2021-05-29 11:10:41', '3', '6', '0', '0');
INSERT INTO `t_comment` VALUES ('31', '<p>嘿嘿，报个到<br/></p>', '3', '2021-04-29 11:11:29', '5', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('32', 'dd', '2', '2021-06-07 11:12:29', '5', '9', '0', '0');
INSERT INTO `t_comment` VALUES ('33', '<p>首发申购顶顶顶顶顶</p>', '5', '2021-05-22 11:12:59', '5', '8', '0', '0');
INSERT INTO `t_comment` VALUES ('34', 'dd', '3', '2021-06-04 11:21:53', '3', '7', '0', '0');
INSERT INTO `t_comment` VALUES ('35', '<p>一起学习哈</p>', '4', '2021-05-27 11:53:16', '1', '2', '0', '0');
INSERT INTO `t_comment` VALUES ('36', '<p>好赞<br/></p>', '9', '2021-05-22 20:27:03', '2', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('37', 'dd', '3', '2021-06-12 20:36:25', '2', '9', '0', '0');
INSERT INTO `t_comment` VALUES ('38', 'dd', '4', '2021-05-30 20:40:56', '2', '9', '0', '0');
INSERT INTO `t_comment` VALUES ('39', '<p>。。。。。。</p>', '7', '2021-05-31 12:44:06', '3', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('40', 'dd', '5', '2021-06-10 12:44:40', '2', '9', '0', '0');
INSERT INTO `t_comment` VALUES ('41', '<p>好赞<br/></p>', '10', '2021-05-31 14:09:45', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('42', '<p>小姐姐有对象吗<br/></p>', '11', '2021-05-13 22:11:27', '2', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('43', '<p>好赞<br/></p>', '12', '2021-05-14 22:25:28', '2', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('44', '<p>凑个热闹啊<br/></p>', '10', '2021-06-11 22:38:59', '1', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('45', '<p>过来了哈哈哈<br/></p>', '11', '2021-05-13 22:41:24', '1', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('46', '<p>先把消息提示取消掉<br/></p>', '12', '2021-05-31 22:42:53', '1', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('47', '<p>不知道<br/></p>', '13', '2021-06-02 22:43:36', '1', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('48', '<p>嘿嘿，我老公<br/></p>', '14', '2021-04-30 22:43:52', '1', '10', '0', '0');
INSERT INTO `t_comment` VALUES ('49', '<p>呵，我能找到工作吗</p>', '6', '2021-06-05 19:20:58', '1', '8', '0', '0');
INSERT INTO `t_comment` VALUES ('50', '<p>加我一个，qq:7589437399</p>', '1', '2021-06-03 01:37:06', '3', '12', '0', '0');
INSERT INTO `t_comment` VALUES ('51', '<p>乒乓球好难</p>', '2', '2021-04-28 01:39:03', '1', '12', '0', '0');
INSERT INTO `t_comment` VALUES ('52', '<p>看见了加一</p>', '13', '2021-05-18 01:49:38', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('53', '<p>我看见过好多次，真是个爱吃汉堡的小姐姐<br/></p>', '14', '2021-05-19 03:23:06', '3', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('54', '<p>赞<br/></p>', '15', '2021-05-23 13:28:59', '1', '5', '0', '0');
INSERT INTO `t_comment` VALUES ('55', '<p>芜湖</p>', '1', '2021-05-13 05:49:50', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('56', '<p>芜湖</p>', '2', '2021-05-16 05:51:05', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('57', '<p>芜湖</p>', '3', '2021-05-20 05:51:13', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('58', '<p>芜湖</p>', '4', '2021-05-13 05:51:31', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('59', '<p>芜湖</p>', '5', '2021-04-28 05:52:09', '3', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('60', '<p>芜湖</p>', '6', '2021-06-13 05:52:17', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('61', '<p>芜湖</p>', '7', '2021-04-27 05:52:20', '3', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('62', '<p>芜湖</p>', '8', '2021-05-06 05:52:36', '3', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('63', '<p>芜湖</p>', '9', '2021-05-09 05:54:03', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('64', '<p>芜湖</p>', '10', '2021-05-13 05:55:04', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('65', '<p>芜湖</p>', '11', '2021-05-23 08:51:06', '5', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('66', '<p>芜湖</p>', '12', '2021-05-28 08:51:32', '5', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('67', '<p>芜湖</p>', '13', '2021-04-30 08:52:04', '5', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('68', '<p>芜湖</p>', '14', '2021-05-31 08:52:35', '5', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('69', '<p>芜湖</p>', '15', '2021-05-03 08:53:05', '5', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('70', '<p>芜湖</p>', '16', '2021-05-02 08:55:22', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('71', '<p>芜湖</p>', '17', '2021-05-24 05:42:59', '3', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('72', '<p>芜湖</p>', '18', '2021-05-27 05:47:00', '8', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('73', '<p>芜湖</p>', '19', '2021-06-14 06:47:43', '1', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('74', '<p>芜湖</p>', '20', '2021-06-04 14:47:58', '2', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('75', '<p>坚持就是胜利<br/></p>', '1', '2021-06-07 19:25:57', '1', '11', '0', '0');
INSERT INTO `t_comment` VALUES ('76', '<p>我觉得还行吧<br/></p>', '1', '2021-04-21 00:00:00', '1', '19', '0', '0');
INSERT INTO `t_comment` VALUES ('77', 'dd', '6', '2021-05-10 16:33:03', '1', '9', '0', '0');
INSERT INTO `t_comment` VALUES ('78', 'dd', '7', '2021-06-10 16:33:19', '1', '9', '0', '0');
INSERT INTO `t_comment` VALUES ('79', '<p>芜湖</p>', '21', '2021-06-12 16:40:02', '5', '13', '0', '0');
INSERT INTO `t_comment` VALUES ('80', '<p>早跑完了</p>', '1', '2021-05-24 14:08:08', '10', '20', '0', '0');
INSERT INTO `t_comment` VALUES ('81', '<p>我</p>', '2', '2021-05-26 14:09:37', '11', '20', '3', '1');
INSERT INTO `t_comment` VALUES ('82', '<p>。。。。。。</p>', '3', '2021-05-25 14:12:35', '12', '20', '2', '1');
INSERT INTO `t_comment` VALUES ('83', '<p>，，，，，</p>', '4', '2021-05-22 14:18:17', '10', '20', '0', '1');

-- ----------------------------
-- Table structure for `t_grade`
-- ----------------------------
DROP TABLE IF EXISTS `t_grade`;
CREATE TABLE `t_grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `honor` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_grade
-- ----------------------------
INSERT INTO `t_grade` VALUES ('1', '1');
INSERT INTO `t_grade` VALUES ('2', '2');
INSERT INTO `t_grade` VALUES ('3', '3');
INSERT INTO `t_grade` VALUES ('4', '4');
INSERT INTO `t_grade` VALUES ('5', '5');
INSERT INTO `t_grade` VALUES ('6', '6');
INSERT INTO `t_grade` VALUES ('7', '7');
INSERT INTO `t_grade` VALUES ('8', '8');
INSERT INTO `t_grade` VALUES ('9', '9');
INSERT INTO `t_grade` VALUES ('10', '10');
INSERT INTO `t_grade` VALUES ('11', '11');
INSERT INTO `t_grade` VALUES ('12', '12');
INSERT INTO `t_grade` VALUES ('13', '13');
INSERT INTO `t_grade` VALUES ('14', '14');
INSERT INTO `t_grade` VALUES ('15', '15');
INSERT INTO `t_grade` VALUES ('16', '16');
INSERT INTO `t_grade` VALUES ('17', '17');
INSERT INTO `t_grade` VALUES ('18', '18');

-- ----------------------------
-- Table structure for `t_help`
-- ----------------------------
DROP TABLE IF EXISTS `t_help`;
CREATE TABLE `t_help` (
  `id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `content` longtext,
  `newtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_help
-- ----------------------------
INSERT INTO `t_help` VALUES ('1', '注册导航', '请用户点击页面顶部最右端“注册”进行注册', '2021-04-11 00:00:00');
INSERT INTO `t_help` VALUES ('2', '登录导航', '请用户点击页面顶部最右端“登录”进行登录', '2021-04-11 00:00:00');

-- ----------------------------
-- Table structure for `t_new`
-- ----------------------------
DROP TABLE IF EXISTS `t_new`;
CREATE TABLE `t_new` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `new_time` datetime DEFAULT NULL,
  `news_comment_user_id` int(11) NOT NULL,
  `news_topic_id` int(11) NOT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `news_comment_user_id` (`news_comment_user_id`),
  KEY `news_topic_id` (`news_topic_id`),
  CONSTRAINT `news_comment_user_id` FOREIGN KEY (`news_comment_user_id`) REFERENCES `t_user` (`id`),
  CONSTRAINT `news_topic_id` FOREIGN KEY (`news_topic_id`) REFERENCES `t_topic` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_new
-- ----------------------------
INSERT INTO `t_new` VALUES ('1', '2021-03-22 18:06:01', '2', '2', '1');
INSERT INTO `t_new` VALUES ('2', '2021-05-07 18:06:46', '2', '1', '1');
INSERT INTO `t_new` VALUES ('3', '2021-05-22 18:08:27', '2', '1', '1');
INSERT INTO `t_new` VALUES ('4', '2021-05-05 10:39:00', '2', '5', '1');
INSERT INTO `t_new` VALUES ('5', '2021-05-22 20:27:03', '2', '5', '1');
INSERT INTO `t_new` VALUES ('6', '2021-05-06 10:42:12', '2', '6', '1');
INSERT INTO `t_new` VALUES ('7', '2021-05-07 10:44:15', '2', '7', '1');
INSERT INTO `t_new` VALUES ('8', '2021-05-22 10:48:51', '1', '8', '0');
INSERT INTO `t_new` VALUES ('9', '2021-05-11 10:58:38', '4', '9', '1');
INSERT INTO `t_new` VALUES ('10', '2021-06-01 11:00:00', '4', '8', '1');
INSERT INTO `t_new` VALUES ('11', '2021-06-04 11:01:39', '4', '2', '1');
INSERT INTO `t_new` VALUES ('12', '2021-05-16 11:02:40', '4', '7', '1');
INSERT INTO `t_new` VALUES ('13', '2021-05-19 11:03:25', '4', '8', '1');
INSERT INTO `t_new` VALUES ('14', '2021-05-18 11:04:17', '4', '6', '1');
INSERT INTO `t_new` VALUES ('15', '2021-05-20 11:05:23', '4', '3', '1');
INSERT INTO `t_new` VALUES ('16', '2021-04-29 11:11:29', '5', '10', '1');
INSERT INTO `t_new` VALUES ('17', '2021-06-07 11:12:29', '5', '9', '1');
INSERT INTO `t_new` VALUES ('18', '2021-05-22 11:12:59', '5', '8', '1');
INSERT INTO `t_new` VALUES ('19', '2021-06-04 11:21:53', '2', '5', '1');
INSERT INTO `t_new` VALUES ('20', '2021-05-31 12:44:06', '3', '10', '1');
INSERT INTO `t_new` VALUES ('21', '2021-05-31 12:41:42', '3', '10', '1');
INSERT INTO `t_new` VALUES ('22', '2021-05-31 12:43:08', '3', '10', '1');
INSERT INTO `t_new` VALUES ('23', '2021-05-31 12:44:06', '3', '10', '1');
INSERT INTO `t_new` VALUES ('24', '2021-05-13 22:11:27', '2', '5', '1');
INSERT INTO `t_new` VALUES ('25', '2021-05-14 22:25:28', '2', '5', '1');
INSERT INTO `t_new` VALUES ('26', '2021-06-11 22:38:59', '1', '10', '1');
INSERT INTO `t_new` VALUES ('27', '2021-05-13 22:41:24', '1', '10', '1');
INSERT INTO `t_new` VALUES ('28', '2021-05-31 22:42:53', '1', '10', '1');
INSERT INTO `t_new` VALUES ('29', '2021-06-02 22:43:36', '1', '10', '1');
INSERT INTO `t_new` VALUES ('30', '2021-04-30 22:43:52', '1', '10', '1');
INSERT INTO `t_new` VALUES ('31', '2021-04-30 22:46:55', '1', '10', '1');
INSERT INTO `t_new` VALUES ('32', '2021-05-30 22:43:52', '1', '10', '1');
INSERT INTO `t_new` VALUES ('33', '2021-05-22 10:48:51', '1', '8', '1');
INSERT INTO `t_new` VALUES ('34', '2021-06-03 01:37:06', '3', '12', '1');
INSERT INTO `t_new` VALUES ('35', '2021-05-19 03:23:06', '3', '5', '1');
INSERT INTO `t_new` VALUES ('36', '2021-04-28 05:52:09', '3', '13', '1');
INSERT INTO `t_new` VALUES ('37', '2021-04-28 05:52:50', '3', '13', '1');
INSERT INTO `t_new` VALUES ('38', '2021-04-28 05:56:21', '3', '13', '1');
INSERT INTO `t_new` VALUES ('39', '2021-05-28 08:51:32', '5', '13', '1');
INSERT INTO `t_new` VALUES ('40', '2021-04-30 08:52:04', '5', '13', '1');
INSERT INTO `t_new` VALUES ('41', '2021-05-31 08:52:35', '5', '13', '1');
INSERT INTO `t_new` VALUES ('42', '2021-05-03 08:53:05', '5', '13', '1');
INSERT INTO `t_new` VALUES ('43', '2021-06-12 16:40:02', '5', '13', '1');
INSERT INTO `t_new` VALUES ('44', '2021-05-06 05:52:36', '3', '13', '1');
INSERT INTO `t_new` VALUES ('45', '2021-05-27 05:47:00', '8', '13', '1');
INSERT INTO `t_new` VALUES ('46', '2021-06-04 14:47:58', '2', '13', '1');
INSERT INTO `t_new` VALUES ('47', '2021-05-10 16:33:03', '1', '9', '0');
INSERT INTO `t_new` VALUES ('48', '2021-06-10 16:33:19', '1', '9', '0');
INSERT INTO `t_new` VALUES ('49', '2021-06-12 16:40:02', '5', '13', '1');
INSERT INTO `t_new` VALUES ('50', '2021-05-26 14:09:37', '11', '20', '1');
INSERT INTO `t_new` VALUES ('51', '2021-05-25 14:12:35', '12', '20', '1');
INSERT INTO `t_new` VALUES ('52', '2021-06-17 20:58:50', '1', '20', '0');
INSERT INTO `t_new` VALUES ('53', '2021-06-17 21:21:55', '1', '9', '0');
INSERT INTO `t_new` VALUES ('54', '2021-06-17 21:22:37', '1', '9', '0');
INSERT INTO `t_new` VALUES ('55', '2021-06-17 21:22:48', '1', '9', '0');
INSERT INTO `t_new` VALUES ('56', '2021-06-17 21:23:01', '1', '9', '0');
INSERT INTO `t_new` VALUES ('57', '2021-06-18 12:13:45', '13', '1', '0');

-- ----------------------------
-- Table structure for `t_topic`
-- ----------------------------
DROP TABLE IF EXISTS `t_topic`;
CREATE TABLE `t_topic` (
  `id` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` longtext,
  `comment_count` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  `topic_time` datetime DEFAULT NULL,
  `topics_user_id` int(11) NOT NULL,
  `topics_type_id` int(11) NOT NULL,
  `nice_topic` int(11) DEFAULT '0',
  `integral` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `topics_user_id` (`topics_user_id`),
  KEY `topics_type_id` (`topics_type_id`),
  CONSTRAINT `topics_type_id` FOREIGN KEY (`topics_type_id`) REFERENCES `t_type` (`id`),
  CONSTRAINT `topics_user_id` FOREIGN KEY (`topics_user_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_topic
-- ----------------------------
INSERT INTO `t_topic` VALUES ('1', '求重装系统', '<p>有人会重装windows的系统吗？</p>', '4', '1', '2021-04-21 00:00:00', '1', '7', '1', '10');
INSERT INTO `t_topic` VALUES ('2', '哪里有维修店啊', '<p>如题</p>', '4', '1', '2021-04-12 17:30:08', '1', '7', '1', '10');
INSERT INTO `t_topic` VALUES ('3', '饮用水', '<p>停水了，日华求饮用水</p>', '1', '1', '2021-04-12 18:00:16', '1', '9', '1', '10');
INSERT INTO `t_topic` VALUES ('4', '怎么加入学校街舞社', '<p>大一新生求加入街舞社</p>', '0', '0', '2021-04-12 18:02:44', '1', '29', '0', '10');
INSERT INTO `t_topic` VALUES ('5', '找人', '<p>上周五一食堂二楼汉堡对面绿色头发的小姐姐好好看哇</p>', '15', '0', '2021-04-13 10:32:27', '1', '36', '0', '10');
INSERT INTO `t_topic` VALUES ('6', '学校小猫', '<p>学校一共有多少只小猫猫呀？</p>', '3', '0', '2021-05-01 15:00:00', '3', '13', '0', '20');
INSERT INTO `t_topic` VALUES ('7', '有人知附近最近有哪些音乐节吗？', '<p>如题</p>', '3', '0', '2021-04-23 00:00:00', '3', '13', '0', '10');
INSERT INTO `t_topic` VALUES ('8', '未来规划', '<p>你以后想做什么</p>', '6', '0', '2021-04-23 15:00:00', '3', '13', '1', '10');
INSERT INTO `t_topic` VALUES ('9', '长春大学怎么走？', '<p>如题</p>', '11', '0', '2021-04-23 00:00:00', '2', '40', '1', '10');
INSERT INTO `t_topic` VALUES ('10', '找人', '<p>求体院王佳一联系方式</p>', '14', '0', '2021-04-23 11:06:59', '4', '36', '0', '10');
INSERT INTO `t_topic` VALUES ('11', '工作太辛苦', '<p>工作太辛苦怎么办</p>', '1', '0', '2021-04-26 00:00:00', '1', '19', '0', '40');
INSERT INTO `t_topic` VALUES ('12', '乒乓球', '<p>净月求一个乒乓球队友陪练</p>', '2', '0', '2021-04-26 01:29:34', '1', '10', '0', '5');
INSERT INTO `t_topic` VALUES ('13', '找小哥哥', '<p>如题</p>', '21', '0', '2021-04-26 05:49:14', '1', '36', '1', '30');
INSERT INTO `t_topic` VALUES ('14', '找老师', '<p>如题</p>', '0', '0', '2021-04-29 08:29:27', '1', '36', '0', '5');
INSERT INTO `t_topic` VALUES ('15', '其他', '<p>随便写写日记</p>', '0', '0', '2021-04-29 08:48:06', '5', '40', '1', '5');
INSERT INTO `t_topic` VALUES ('16', '博硕路', '<p>如题</p>', '0', '0', '2021-04-26 16:51:07', '1', '37', '0', '5');
INSERT INTO `t_topic` VALUES ('17', '找人', '<p>如题</p>', '0', '0', '2021-04-29 00:00:00', '1', '36', '0', '5');
INSERT INTO `t_topic` VALUES ('18', '找人', '<p>如题</p>', '0', '0', '2021-05-30 16:55:44', '5', '40', '0', '5');
INSERT INTO `t_topic` VALUES ('19', '关于一食堂二楼餐厅的减脂餐', '<p>一食堂二楼今年新开了减脂餐，大家觉得好吃不好吃嘞？</p>', '1', '0', '2021-05-30 17:59:00', '1', '1', '1', '10');
INSERT INTO `t_topic` VALUES ('20', '约跑', '<p>有一起约校园跑的吗</p>', '5', '1', '2021-05-30 18:00:00', '10', '31', '0', '5');

-- ----------------------------
-- Table structure for `t_type`
-- ----------------------------
DROP TABLE IF EXISTS `t_type`;
CREATE TABLE `t_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `count_topics` int(11) DEFAULT '0',
  `count_comments` int(11) DEFAULT '0',
  `is_admin_type` int(11) DEFAULT '0',
  `types_category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `types_category_id` (`types_category_id`),
  CONSTRAINT `types_category_id` FOREIGN KEY (`types_category_id`) REFERENCES `t_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_type
-- ----------------------------
INSERT INTO `t_type` VALUES ('1', '校园一角', '2', '2', '0', '1');
INSERT INTO `t_type` VALUES ('2', '本周大事', '1', '0', '0', '1');
INSERT INTO `t_type` VALUES ('3', '好课推荐', '0', '0', '0', '1');
INSERT INTO `t_type` VALUES ('4', '其他', '0', '0', '0', '1');
INSERT INTO `t_type` VALUES ('5', '快递代取', '0', '0', '0', '2');
INSERT INTO `t_type` VALUES ('6', '失物招领', '0', '0', '0', '2');
INSERT INTO `t_type` VALUES ('7', '维修电子产品', '2', '8', '0', '2');
INSERT INTO `t_type` VALUES ('8', '校园急事', '0', '0', '0', '2');
INSERT INTO `t_type` VALUES ('9', '学院跑腿', '1', '1', '0', '2');
INSERT INTO `t_type` VALUES ('10', '运动打卡', '1', '2', '0', '3');
INSERT INTO `t_type` VALUES ('11', '美食推荐', '0', '0', '0', '3');
INSERT INTO `t_type` VALUES ('12', '音乐分享', '0', '0', '0', '3');
INSERT INTO `t_type` VALUES ('13', '其他', '3', '12', '0', '3');
INSERT INTO `t_type` VALUES ('14', '资源分享', '0', '0', '0', '4');
INSERT INTO `t_type` VALUES ('15', '二手书', '0', '0', '0', '4');
INSERT INTO `t_type` VALUES ('16', '期末讨论', '0', '0', '0', '4');
INSERT INTO `t_type` VALUES ('17', '问题解题', '0', '0', '0', '4');
INSERT INTO `t_type` VALUES ('18', '考研分享', '0', '0', '0', '4');
INSERT INTO `t_type` VALUES ('19', '工作分享', '1', '1', '0', '4');
INSERT INTO `t_type` VALUES ('20', '其他', '0', '0', '0', '4');
INSERT INTO `t_type` VALUES ('21', '校园介绍', '0', '0', '0', '5');
INSERT INTO `t_type` VALUES ('22', '家长须知', '0', '0', '0', '5');
INSERT INTO `t_type` VALUES ('23', '交通', '0', '0', '0', '5');
INSERT INTO `t_type` VALUES ('24', '其他', '0', '0', '0', '5');
INSERT INTO `t_type` VALUES ('25', '纳新', '0', '0', '0', '6');
INSERT INTO `t_type` VALUES ('26', '近期活动', '0', '0', '0', '6');
INSERT INTO `t_type` VALUES ('27', '社团', '0', '0', '0', '6');
INSERT INTO `t_type` VALUES ('28', '组织', '0', '0', '0', '6');
INSERT INTO `t_type` VALUES ('29', '其他', '1', '0', '0', '6');
INSERT INTO `t_type` VALUES ('30', '吐槽', '0', '0', '0', '7');
INSERT INTO `t_type` VALUES ('31', '夜谈', '1', '5', '0', '7');
INSERT INTO `t_type` VALUES ('32', '故事会', '0', '0', '0', '7');
INSERT INTO `t_type` VALUES ('33', '防骗防盗', '0', '0', '0', '7');
INSERT INTO `t_type` VALUES ('34', '小说聚集地', '0', '0', '0', '7');
INSERT INTO `t_type` VALUES ('35', '其他', '0', '0', '0', '7');
INSERT INTO `t_type` VALUES ('36', '捞人', '5', '53', '0', '8');
INSERT INTO `t_type` VALUES ('37', '其他', '1', '0', '0', '8');
INSERT INTO `t_type` VALUES ('38', '周边学校', '0', '0', '0', '9');
INSERT INTO `t_type` VALUES ('39', '净月风光', '0', '0', '0', '9');
INSERT INTO `t_type` VALUES ('40', '其他', '3', '11', '0', '9');
INSERT INTO `t_type` VALUES ('41', '老乡聚集地', '0', '0', '0', '10');
INSERT INTO `t_type` VALUES ('42', '其他', '0', '0', '0', '10');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `nickname` varchar(32) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `come_from` varchar(200) DEFAULT NULL,
  `introduction` longtext,
  `profession` varchar(40) DEFAULT NULL,
  `grade_integal` int(11) DEFAULT '0',
  `integral` int(11) DEFAULT NULL,
  `clock` int(11) DEFAULT NULL,
  `topic_count` int(11) DEFAULT NULL,
  `comment_count` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT '0',
  `users_grade_id` int(11) NOT NULL,
  `register_time` datetime DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `usersGrade_id` (`users_grade_id`),
  CONSTRAINT `usersGrade_id` FOREIGN KEY (`users_grade_id`) REFERENCES `t_grade` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'admin', '123456', 'admin', '女', '/Share_My_Life/image/user.png', 'adminsml@163.com', '长春', '信科', '软件工程', '80', '98', '1', '8', '28', '16', '1', '2021-04-11 00:00:00', '0');
INSERT INTO `t_user` VALUES ('2', 'qwe', '123456', 'qwe', '女', '/u/uploadPic/qwe.jpg', '1234563@qq.com', '快乐星球', '信科', '软件工程', '20', '91', '6', '0', '2', '6', '1', '2021-04-11 00:00:00', '0');
INSERT INTO `t_user` VALUES ('3', 'rty', '654321', '(:)', '女', '/Share_My_Life/u/uploadPic/rty.jpg', '234567@qq.com', '人间', '环院', '啦啦啦', '20', '78', '0', '0', '6', '16', '1', '2021-04-11 00:00:00', '0');
INSERT INTO `t_user` VALUES ('4', 'zxc', '654321', '天蓝蓝', '男', '/Share_My_Life/image/user.png', '345678@163.com', '香飘飘', '外星', '略略略', '0', '61', '0', '0', '0', '6', '1', '2021-04-12 00:00:00', '1');
INSERT INTO `t_user` VALUES ('5', 'jhsa', '654321', '草绿绿', '女', '/u/uploadPic/jhsa.jpg', '123456@126.com', '花园', '猜猜看', '人类工程', '-40', '10', '0', '2', '6', '6', '1', '2021-04-12 00:00:00', '0');
INSERT INTO `t_user` VALUES ('6', '12', '111111', '花红红', '女', '/Share_My_Life/image/user.png', '666@qq.com', '英国', '美院', '工笔画', '0', '50', '0', '0', '0', '0', '1', '2021-04-12 00:00:00', '1');
INSERT INTO `t_user` VALUES ('7', '45', '222222', '糖甜甜', '男', '/Share_My_Life/image/user.png', '0000@163.com', '美国', '外院', '日语', '0', '50', '0', '0', '0', '0', '1', '2021-04-12 00:00:00', '0');
INSERT INTO `t_user` VALUES ('8', '67', '333333', '盐咸咸', '女', '/u/uploadPic/67.jpg', '1234567@qq.com', '阿国', '体院', 'dvdsbv', '0', '51', '0', '0', '1', '0', '1', '2021-04-12 00:00:00', '0');
INSERT INTO `t_user` VALUES ('9', 'hannan', '444444', '喜羊羊', '女', '/Share_My_Life/image/user.png', 'zxcvb@163.com', '啦啦啦', '政法', '法学', '0', '50', '0', '0', '0', '6', '1', '2021-04-13 00:00:00', '0');
INSERT INTO `t_user` VALUES ('10', 'yunnan', '555555', '灰太狼', '男', '/Share_My_Life/u/uploadPic/user.jpg', 'smail@qq.com', '天堂', '化院', '生物化学', '0', '49', '1', '1', '2', '6', '1', '2021-04-13 00:00:00', '0');
INSERT INTO `t_user` VALUES ('11', '❀', '666666', '小花', '女', '/Share_My_Life/image/user.png', 'water@qq.com', '地狱', '数院', '高等数学', '0', '53', '0', '0', '1', '0', '1', '2021-04-13 00:00:00', '1');
INSERT INTO `t_user` VALUES ('12', '(((φ(◎ロ◎;)φ)))', '777777', '小草', '男', '/Share_My_Life/image/user.png', 'people@126.com', '地府', '信科', '计算机', '0', '52', '0', '0', '1', '0', '1', '2021-04-13 00:00:00', '0');
INSERT INTO `t_user` VALUES ('13', '122', '112233', '112', '女', '/Share_My_Life/u/uploadPic/20210618-12-16-58-捕获.PNG', '112@qq.com', '长春', '信科', '软件', '0', '51', '0', '0', '1', '0', '1', '2021-06-18 12:13:08', '0');
